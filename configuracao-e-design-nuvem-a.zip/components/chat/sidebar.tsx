'use client'

import type { UIMessage } from 'ai'
import { MessageSquare, SquarePen, Trash2, X, Sparkles } from 'lucide-react'
import { cn } from '@/lib/utils'
import { Logo } from './logo'

export type Conversation = {
  id: string
  title: string
  messages: UIMessage[]
}

type SidebarProps = {
  conversations: Conversation[]
  activeId: string
  open: boolean
  onClose: () => void
  onSelect: (id: string) => void
  onNewChat: () => void
  onDelete: (id: string) => void
}

export function Sidebar({ conversations, activeId, open, onClose, onSelect, onNewChat, onDelete }: SidebarProps) {
  return (
    <>
      <div
        className={cn(
          'fixed inset-0 z-30 bg-black/60 backdrop-blur-sm transition-opacity md:hidden',
          open ? 'opacity-100' : 'pointer-events-none opacity-0',
        )}
        onClick={onClose}
        aria-hidden="true"
      />
      <aside
        className={cn(
          'fixed inset-y-0 left-0 z-40 flex w-72 flex-col border-r border-sidebar-border bg-sidebar transition-transform md:static md:translate-x-0',
          open ? 'translate-x-0' : '-translate-x-full',
        )}
        aria-label="Conversas"
      >
        <div className="flex h-14 items-center justify-between px-4">
          <Logo />
          <button
            type="button"
            onClick={onClose}
            className="flex size-8 items-center justify-center rounded-lg text-muted-foreground hover:bg-sidebar-accent hover:text-foreground md:hidden"
            aria-label="Fechar menu"
          >
            <X className="size-4" />
          </button>
        </div>

        <div className="px-3 pb-2">
          <button
            type="button"
            onClick={onNewChat}
            className="flex w-full items-center gap-2 rounded-lg border border-border px-3 py-2.5 text-sm font-medium transition-colors hover:border-primary/40 hover:bg-sidebar-accent"
          >
            <SquarePen className="size-4 text-primary" />
            Nova conversa
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 py-2" aria-label="Histórico">
          <p className="px-2 pb-2 font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
            Recentes
          </p>
          <ul className="flex flex-col gap-0.5">
            {conversations.map((c) => (
              <li key={c.id} className="group relative">
                <button
                  type="button"
                  onClick={() => onSelect(c.id)}
                  aria-current={c.id === activeId ? 'page' : undefined}
                  className={cn(
                    'flex w-full items-center gap-2 rounded-lg px-2 py-2 pr-9 text-left text-sm transition-colors',
                    c.id === activeId
                      ? 'bg-sidebar-accent text-foreground'
                      : 'text-muted-foreground hover:bg-sidebar-accent/60 hover:text-foreground',
                  )}
                >
                  <MessageSquare className="size-4 shrink-0" />
                  <span className="truncate">{c.title}</span>
                </button>
                <button
                  type="button"
                  onClick={() => onDelete(c.id)}
                  className="absolute top-1/2 right-1.5 flex size-7 -translate-y-1/2 items-center justify-center rounded-md text-muted-foreground opacity-0 transition-opacity hover:text-destructive focus-visible:opacity-100 group-hover:opacity-100"
                  aria-label={`Apagar conversa: ${c.title}`}
                >
                  <Trash2 className="size-3.5" />
                </button>
              </li>
            ))}
          </ul>
        </nav>

        <div className="border-t border-sidebar-border p-3">
          <div className="flex items-center gap-3 rounded-lg px-2 py-2">
            <span className="flex size-8 items-center justify-center rounded-full bg-gradient-to-br from-primary/30 to-chart-2/30 text-primary">
              <Sparkles className="size-4" />
            </span>
            <div className="min-w-0">
              <p className="text-sm font-medium">Nuvem-aí</p>
              <p className="truncate text-xs text-muted-foreground">nuvem-ai.com</p>
            </div>
          </div>
        </div>
      </aside>
    </>
  )
}
