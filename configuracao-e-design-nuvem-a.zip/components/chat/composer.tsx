'use client'

import { useRef, useState } from 'react'
import { ArrowUp, Square } from 'lucide-react'
import { cn } from '@/lib/utils'

type ComposerProps = {
  onSend: (text: string) => void
  onStop: () => void
  isBusy: boolean
  autoFocus?: boolean
}

export function Composer({ onSend, onStop, isBusy, autoFocus }: ComposerProps) {
  const [value, setValue] = useState('')
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  const submit = () => {
    const text = value.trim()
    if (!text || isBusy) return
    onSend(text)
    setValue('')
    if (textareaRef.current) textareaRef.current.style.height = 'auto'
  }

  return (
    <div>
      <form
        onSubmit={(e) => {
          e.preventDefault()
          submit()
        }}
        className="group relative flex items-end gap-2 rounded-2xl border border-border bg-card p-2 shadow-[0_0_40px_-12px] shadow-primary/25 transition-colors focus-within:border-primary/50"
      >
        <label htmlFor="chat-input" className="sr-only">
          Mensagem para a Nuvem-aí
        </label>
        <textarea
          id="chat-input"
          ref={textareaRef}
          value={value}
          autoFocus={autoFocus}
          rows={1}
          placeholder="Pergunte qualquer coisa à Nuvem-aí…"
          onChange={(e) => {
            setValue(e.target.value)
            e.target.style.height = 'auto'
            e.target.style.height = `${Math.min(e.target.scrollHeight, 200)}px`
          }}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              if (e.nativeEvent.isComposing || e.keyCode === 229) return
              e.preventDefault()
              submit()
            }
          }}
          className="max-h-[200px] min-h-11 flex-1 resize-none bg-transparent px-3 py-2.5 text-[15px] leading-relaxed outline-none placeholder:text-muted-foreground"
        />
        {isBusy ? (
          <button
            type="button"
            onClick={onStop}
            className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-foreground text-background transition-opacity hover:opacity-90"
            aria-label="Parar resposta"
          >
            <Square className="size-3.5 fill-current" />
          </button>
        ) : (
          <button
            type="submit"
            disabled={!value.trim()}
            className={cn(
              'flex size-10 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground transition-all hover:brightness-110',
              'disabled:cursor-not-allowed disabled:bg-muted disabled:text-muted-foreground',
            )}
            aria-label="Enviar mensagem"
          >
            <ArrowUp className="size-5" />
          </button>
        )}
      </form>
      <p className="mt-2 text-center text-xs text-muted-foreground">
        A Nuvem-aí pode cometer erros. Confira informações importantes.
      </p>
    </div>
  )
}
