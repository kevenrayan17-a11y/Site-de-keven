import { Cloud } from 'lucide-react'
import { cn } from '@/lib/utils'

export function LogoMark({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        'relative flex size-8 shrink-0 items-center justify-center rounded-lg border border-primary/30 bg-primary/10 text-primary shadow-[0_0_20px_-4px] shadow-primary/50',
        className,
      )}
      aria-hidden="true"
    >
      <Cloud className="size-4" strokeWidth={2.25} />
    </span>
  )
}

export function Logo() {
  return (
    <span className="flex items-center gap-2.5">
      <LogoMark />
      <span className="text-[15px] font-semibold tracking-tight">
        Nuvem<span className="text-primary">-aí</span>
      </span>
    </span>
  )
}
