'use client'

import { useEffect, useRef } from 'react'
import { useChat } from '@ai-sdk/react'
import type { UIMessage } from 'ai'
import { RotateCcw } from 'lucide-react'
import { Composer } from './composer'
import { EmptyState } from './empty-state'
import { ChatMessage, ThinkingIndicator } from './chat-message'

type ChatPanelProps = {
  id: string
  initialMessages: UIMessage[]
  onMessagesChange: (id: string, messages: UIMessage[]) => void
}

export function ChatPanel({ id, initialMessages, onMessagesChange }: ChatPanelProps) {
  const { messages, sendMessage, status, stop, error, regenerate } = useChat({
    id,
    messages: initialMessages,
  })
  const bottomRef = useRef<HTMLDivElement>(null)
  const isBusy = status === 'submitted' || status === 'streaming'

  useEffect(() => {
    if (status === 'ready' || status === 'error') onMessagesChange(id, messages)
  }, [status, messages, id, onMessagesChange])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' })
  }, [messages, status])

  const send = (text: string) => sendMessage({ text })

  if (messages.length === 0) {
    return (
      <main className="flex flex-1 flex-col overflow-y-auto">
        <EmptyState onPick={send} />
        <div className="mx-auto w-full max-w-3xl px-4 pb-4">
          <Composer onSend={send} onStop={stop} isBusy={isBusy} autoFocus />
        </div>
      </main>
    )
  }

  return (
    <main className="flex min-h-0 flex-1 flex-col">
      <div className="flex-1 overflow-y-auto">
        <div className="mx-auto flex w-full max-w-3xl flex-col gap-8 px-4 py-8" aria-live="polite">
          {messages.map((m) => (
            <ChatMessage key={m.id} message={m} />
          ))}
          {status === 'submitted' && <ThinkingIndicator />}
          {error && (
            <div className="flex items-center justify-between gap-3 rounded-xl border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm">
              <span>Ops, algo deu errado ao responder. Tente novamente.</span>
              <button
                type="button"
                onClick={() => regenerate()}
                className="flex items-center gap-1.5 rounded-md px-2 py-1 font-medium hover:bg-destructive/20"
              >
                <RotateCcw className="size-3.5" />
                Tentar de novo
              </button>
            </div>
          )}
          <div ref={bottomRef} />
        </div>
      </div>
      <div className="mx-auto w-full max-w-3xl px-4 pb-4">
        <Composer onSend={send} onStop={stop} isBusy={isBusy} />
      </div>
    </main>
  )
}
