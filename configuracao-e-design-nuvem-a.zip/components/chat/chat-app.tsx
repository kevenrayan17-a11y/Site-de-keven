'use client'

import { useCallback, useState } from 'react'
import type { UIMessage } from 'ai'
import { PanelLeft, SquarePen } from 'lucide-react'
import { Sidebar, type Conversation } from './sidebar'
import { ChatPanel } from './chat-panel'
import { Logo } from './logo'

function createConversation(): Conversation {
  return { id: crypto.randomUUID(), title: 'Nova conversa', messages: [] }
}

function getTitle(messages: UIMessage[]) {
  const firstUser = messages.find((m) => m.role === 'user')
  const text = firstUser?.parts.find((p) => p.type === 'text')
  if (!text || text.type !== 'text') return 'Nova conversa'
  return text.text.length > 40 ? `${text.text.slice(0, 40)}…` : text.text
}

export function ChatApp() {
  const [conversations, setConversations] = useState<Conversation[]>(() => [createConversation()])
  const [activeId, setActiveId] = useState(() => conversations[0].id)
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const active = conversations.find((c) => c.id === activeId) ?? conversations[0]

  const startNewChat = () => {
    setSidebarOpen(false)
    if (active.messages.length === 0) return
    const next = createConversation()
    setConversations((prev) => [next, ...prev])
    setActiveId(next.id)
  }

  const handleMessagesChange = useCallback((id: string, messages: UIMessage[]) => {
    setConversations((prev) =>
      prev.map((c) => (c.id === id ? { ...c, messages, title: getTitle(messages) } : c)),
    )
  }, [])

  const deleteConversation = (id: string) => {
    const remaining = conversations.filter((c) => c.id !== id)
    if (remaining.length === 0) {
      const fresh = createConversation()
      setConversations([fresh])
      setActiveId(fresh.id)
      return
    }
    setConversations(remaining)
    if (id === activeId) setActiveId(remaining[0].id)
  }

  return (
    <div className="flex h-dvh overflow-hidden bg-background">
      <Sidebar
        conversations={conversations}
        activeId={active.id}
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        onSelect={(id) => {
          setActiveId(id)
          setSidebarOpen(false)
        }}
        onNewChat={startNewChat}
        onDelete={deleteConversation}
      />

      <div className="relative flex min-w-0 flex-1 flex-col">
        <header className="flex h-14 shrink-0 items-center justify-between border-b border-border px-3 md:hidden">
          <button
            type="button"
            onClick={() => setSidebarOpen(true)}
            className="flex size-9 items-center justify-center rounded-lg text-muted-foreground hover:bg-accent hover:text-foreground"
            aria-label="Abrir menu"
          >
            <PanelLeft className="size-5" />
          </button>
          <Logo />
          <button
            type="button"
            onClick={startNewChat}
            className="flex size-9 items-center justify-center rounded-lg text-muted-foreground hover:bg-accent hover:text-foreground"
            aria-label="Nova conversa"
          >
            <SquarePen className="size-5" />
          </button>
        </header>

        <ChatPanel
          key={active.id}
          id={active.id}
          initialMessages={active.messages}
          onMessagesChange={handleMessagesChange}
        />
      </div>
    </div>
  )
}
