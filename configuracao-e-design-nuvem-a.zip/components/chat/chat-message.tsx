'use client'

import { useState } from 'react'
import type { UIMessage } from 'ai'
import ReactMarkdown from 'react-markdown'
import { Check, Copy } from 'lucide-react'
import { LogoMark } from './logo'

function getText(message: UIMessage) {
  return message.parts
    .filter((p) => p.type === 'text')
    .map((p) => (p.type === 'text' ? p.text : ''))
    .join('')
}

export function ChatMessage({ message }: { message: UIMessage }) {
  const text = getText(message)

  if (message.role === 'user') {
    return (
      <div className="flex justify-end">
        <p className="max-w-[85%] whitespace-pre-wrap rounded-2xl rounded-br-md bg-secondary px-4 py-2.5 text-[15px] leading-relaxed">
          {text}
        </p>
      </div>
    )
  }

  return (
    <div className="group flex gap-4">
      <LogoMark />
      <div className="min-w-0 flex-1 pt-1">
        <div className="prose-chat text-[15px] leading-relaxed">
          <ReactMarkdown
            components={{
              p: (props) => <p className="mb-4 last:mb-0" {...props} />,
              ul: (props) => <ul className="mb-4 list-disc space-y-1.5 pl-6 last:mb-0" {...props} />,
              ol: (props) => <ol className="mb-4 list-decimal space-y-1.5 pl-6 last:mb-0" {...props} />,
              h1: (props) => <h2 className="mt-6 mb-3 text-xl font-semibold first:mt-0" {...props} />,
              h2: (props) => <h3 className="mt-6 mb-3 text-lg font-semibold first:mt-0" {...props} />,
              h3: (props) => <h4 className="mt-5 mb-2 font-semibold first:mt-0" {...props} />,
              a: (props) => <a className="text-primary underline underline-offset-4" target="_blank" rel="noreferrer" {...props} />,
              strong: (props) => <strong className="font-semibold text-foreground" {...props} />,
              blockquote: (props) => <blockquote className="mb-4 border-l-2 border-primary/50 pl-4 text-muted-foreground" {...props} />,
              pre: (props) => (
                <pre className="mb-4 overflow-x-auto rounded-xl border border-border bg-sidebar p-4 font-mono text-[13px] leading-relaxed last:mb-0" {...props} />
              ),
              code: ({ className, ...props }) =>
                className ? (
                  <code className={className} {...props} />
                ) : (
                  <code className="rounded-md bg-secondary px-1.5 py-0.5 font-mono text-[13px] text-primary" {...props} />
                ),
            }}
          >
            {text}
          </ReactMarkdown>
        </div>
        {text && <CopyButton text={text} />}
      </div>
    </div>
  )
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false)
  return (
    <button
      type="button"
      onClick={async () => {
        await navigator.clipboard.writeText(text)
        setCopied(true)
        setTimeout(() => setCopied(false), 1500)
      }}
      className="mt-2 flex size-8 items-center justify-center rounded-md text-muted-foreground opacity-0 transition-opacity hover:bg-accent hover:text-foreground focus-visible:opacity-100 group-hover:opacity-100"
      aria-label={copied ? 'Copiado' : 'Copiar resposta'}
    >
      {copied ? <Check className="size-4" /> : <Copy className="size-4" />}
    </button>
  )
}

export function ThinkingIndicator() {
  return (
    <div className="flex items-center gap-4" role="status">
      <LogoMark className="animate-pulse" />
      <span className="flex gap-1" aria-hidden="true">
        <span className="size-1.5 animate-bounce rounded-full bg-primary [animation-delay:-0.3s]" />
        <span className="size-1.5 animate-bounce rounded-full bg-primary [animation-delay:-0.15s]" />
        <span className="size-1.5 animate-bounce rounded-full bg-primary" />
      </span>
      <span className="sr-only">A Nuvem-aí está pensando…</span>
    </div>
  )
}
