import { Code2, Lightbulb, PenLine, GraduationCap } from 'lucide-react'
import { LogoMark } from './logo'

const suggestions = [
  { icon: Lightbulb, title: 'Ter ideias', prompt: 'Me dê 5 ideias criativas de nomes para uma cafeteria moderna' },
  { icon: PenLine, title: 'Escrever um texto', prompt: 'Escreva uma mensagem profissional pedindo uma reunião com um cliente' },
  { icon: GraduationCap, title: 'Aprender algo', prompt: 'Explique de forma simples como funciona a inteligência artificial' },
  { icon: Code2, title: 'Programar', prompt: 'Crie uma função em JavaScript que valida um e-mail' },
]

export function EmptyState({ onPick }: { onPick: (text: string) => void }) {
  return (
    <div className="relative flex flex-1 flex-col items-center justify-center px-4 py-12">
      <div
        className="pointer-events-none absolute inset-0 -z-0 bg-[radial-gradient(ellipse_50%_40%_at_50%_35%,oklch(0.82_0.13_205/0.12),transparent)]"
        aria-hidden="true"
      />
      <div className="relative flex w-full max-w-3xl flex-col items-center text-center">
        <LogoMark className="size-14 rounded-2xl [&>svg]:size-7" />
        <h1 className="mt-6 text-balance text-3xl font-semibold tracking-tight md:text-4xl">
          Como posso ajudar hoje?
        </h1>
        <p className="mt-3 max-w-md text-pretty text-muted-foreground">
          Sou a <span className="text-foreground">Nuvem-aí</span>, sua inteligência artificial. Pergunte, crie, escreva ou programe.
        </p>

        <ul className="mt-10 grid w-full grid-cols-1 gap-3 sm:grid-cols-2">
          {suggestions.map(({ icon: Icon, title, prompt }) => (
            <li key={title}>
              <button
                type="button"
                onClick={() => onPick(prompt)}
                className="flex h-full w-full items-start gap-3 rounded-xl border border-border bg-card/60 p-4 text-left transition-colors hover:border-primary/40 hover:bg-card"
              >
                <Icon className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden="true" />
                <span>
                  <span className="block text-sm font-medium">{title}</span>
                  <span className="mt-1 block text-sm text-muted-foreground">{prompt}</span>
                </span>
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}
