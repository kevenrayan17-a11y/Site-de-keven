import {
  streamText,
  type UIMessage,
  convertToModelMessages,
  createUIMessageStreamResponse,
  toUIMessageStream,
} from 'ai'

export const maxDuration = 60

const MAX_MESSAGES = 40

export async function POST(req: Request) {
  const body = await req.json().catch(() => null)
  const messages: UIMessage[] | undefined = body?.messages

  if (!Array.isArray(messages) || messages.length === 0) {
    return Response.json({ error: 'Mensagens inválidas.' }, { status: 400 })
  }

  const safeMessages = messages
    .filter((m) => m.role === 'user' || m.role === 'assistant')
    .slice(-MAX_MESSAGES)

  const result = streamText({
    model: 'openai/gpt-5.4-mini',
    instructions:
      'Você é a Nuvem-aí, uma assistente de inteligência artificial amigável, clara e útil. Responda em português do Brasil por padrão (ou no idioma do usuário, se ele escrever em outro). Use Markdown quando ajudar na leitura: listas, títulos curtos e blocos de código.',
    messages: await convertToModelMessages(safeMessages),
  })

  return createUIMessageStreamResponse({
    stream: toUIMessageStream({ stream: result.stream }),
  })
}
